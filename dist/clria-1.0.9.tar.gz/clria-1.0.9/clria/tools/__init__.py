from ._mmot import MMOTNTD
from ._spin import gen_permM
from ._tca import TCA, SC_L_decomposition
from ._uotr import UOTRegression, OTRegression