from ._iot import generate_coupling_matrix
from ._iot import simu_data